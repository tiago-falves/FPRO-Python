def count(word,phrase):
    phrase=phrase.lower()
    word=word.lower()
    a=phrase.count(word)
    return a
