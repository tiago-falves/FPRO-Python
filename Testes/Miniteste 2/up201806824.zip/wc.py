def wc(filename):
    lnum = 0
    wnum = 0
    cnum = 0
    with open(filename, 'r') as file:
        for line in file:
            lnum += 1
            for char in line:
                cnum += 1
            for word in line.split():
                wnum += 1
    final = (lnum, wnum, cnum)
    return final
