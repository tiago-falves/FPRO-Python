def override(l1,l2):
    return sorted(l,key=lambda x:)