def inner(u,v):
    soma=0
    for i in range (len(u)):
        soma+=u[i]*v[i]   
    return soma

        