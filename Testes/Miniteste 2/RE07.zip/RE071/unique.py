def unique(atuple):
    a=()
    for i in range(len(atuple)):
        k=0
        for j in range(i+1,len(atuple)):
            if atuple[i]==atuple[j]:
                k+=1
        if k==0:
            a+=(atuple[i],)
    a=tuple(sorted(a))
    return a
