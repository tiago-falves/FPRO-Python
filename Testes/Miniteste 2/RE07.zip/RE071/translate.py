def translate(astring, table):
    a=""
    for ch in astring:
        s=ch
        for obj in table:
            if ch==obj[0]:
                s=str(obj[1])
                break
        a+=s
    return a