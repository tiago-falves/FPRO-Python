def find_dtype(atuple, data_type):
    s=()
    for obj in atuple:
        if type(obj).__name__== data_type:
            s+=(obj,)
    return s